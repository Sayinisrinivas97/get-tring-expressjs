# Get a String

Given an `app.js` file, write an API with path `/` using express JS to send `Express JS` text as a response.

Export the express instance using default export syntax.

<b>Use Common JS module syntax</b>.
